from library.ai.MaskRCNN.main import Predict

if __name__ == '__main__':
    predict = Predict()
    predict.start()
    