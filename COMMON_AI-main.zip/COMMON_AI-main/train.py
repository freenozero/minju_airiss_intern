from library.ai.MaskRCNN.main import Train

if __name__ == '__main__':
    train =Train()
    train.start()
    